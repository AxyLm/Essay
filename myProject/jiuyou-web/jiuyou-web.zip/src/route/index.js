const _import = path => () => import( /* @vite-ignore */ '/src' + path + '.vue')
const router = [
    {
        path: '/',
        name: 'Layout',
        component: _import('/layout/index'),
        children: [
            {
                path: 'photo',
                name: 'Photo',
                component: _import('/pages/photo/index')
            },
            {
                path: 'travel',
                name: 'Travel',
                component: _import('/pages/travel/index')
            },
        ]
    },
    {
        path: "/err/:type?",
        name: 'errPage',
        component: _import("/pages/errPage/index")
    }
]


export default router