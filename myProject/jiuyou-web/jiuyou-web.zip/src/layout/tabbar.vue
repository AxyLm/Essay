<template>
    <Tabbar :route="true">
        <Tabbar-item  v-for="item in tabConfig" :icon="item.icon" :to="item.to">{{item.title}}</Tabbar-item>
    </Tabbar>
</template>
<script>
	import { Tabbar, TabbarItem } from "vant";
	import { reactive, ref } from "@vue/reactivity";
    export default {
		setup() {
            const active = ref(0);
			const state = reactive({
				tabConfig: [
					{
						to: "/photo",
						title: "照片",
						icon: "photo",
					},
                    {
						to: "/travel",
						title: "旅途",
						icon: "like",
					},
				],
			});

            return{
                ...state,
                active
            }
		},
        components:{
            Tabbar, TabbarItem
        }
    }

</script>

