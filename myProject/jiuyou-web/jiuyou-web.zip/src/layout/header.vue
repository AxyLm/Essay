<template>
	<NavBar title="标题" left-text="返回" left-arrow></NavBar>
</template>
<script>
	import { NavBar } from "vant";

    export default{
        components: {
            NavBar
        }
    }
</script>

