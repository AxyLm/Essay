<template>
	<div id="app-content">
		<router-view></router-view>
	</div>
	<Tabbar />
</template>
<script setup>
	import Tabbar from "./tabbar.vue";
	import Header from "./header.vue";
</script>