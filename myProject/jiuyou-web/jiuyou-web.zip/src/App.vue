<template>
  <router-view></router-view>
</template>
<style>
*{
  margin:0;
  padding:0;
}
#app{
  height:100vh;
  overflow: hidden;
}
</style>