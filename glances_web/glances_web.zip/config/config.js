"use strict"
module.exports={
    SERVER_NAME:'glances_web',
    SERVER_PORT:'8233'
}