export default {
    el:'#cpu',
    name:'cpu',
    data() {
        return {
            data: 'cpu'
        }
    },
}