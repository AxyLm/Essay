SSID = "wifi_name"
PASSW = "password"
LOCATION = "stockholm,se"
OPENWEATHER_ID = "openweather-id"