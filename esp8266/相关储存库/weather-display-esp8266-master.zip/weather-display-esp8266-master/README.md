# weather-display-esp8266
A micropython program that runs on a esp8366 and pulls weather data and display it on a i2c oled display
